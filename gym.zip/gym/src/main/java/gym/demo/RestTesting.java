package gym.demo;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.util.List;
@Component

public class RestTesting implements CommandLineRunner{

    @Override

    public void run(String...args)throws Exception{
        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<List<University>> response =restTemplate.exchange(
                "http://10.51.10.111:8080/universities",
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<University>>(){});{
                }
        List<University> universities = response.getBody();


        for(University university:universities){
            System.out.println(university.toString());
        }

        University university= restTemplate.getForObject(
                "http://10.51.10.111:8080/universities/2",
                University.class);
        System.out.println(university.toString());
        System.out.println("Creating POST........");

        University newUniversity = new University("Chuka","Meru",9.5888,2.878,2000, 2 );
        University createdUniversity=restTemplate.postForObject("http://10.51.10.111:8080/universities",

                newUniversity, University.class);
        System.out.println(createdUniversity.toString());

        String creatCourseUrl="http://10.51.10.111:8080/universities/"+createdUniversity.getId()+"/courses";


        Courses newcourses=new Courses("Bsc ICS");
        Courses createdCourses=restTemplate.postForObject(creatCourseUrl, newcourses,Courses.class);
        System.out.println(createdCourses.toString());


    }

}
